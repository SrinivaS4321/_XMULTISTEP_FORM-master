
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("multi-step-form");
    const steps = [...document.querySelectorAll(".form-step")];
    const stepItems = [...document.querySelectorAll(".step-item")];
    const planCards = [...document.querySelectorAll(".plan_card")];
    const addonCards = [...document.querySelectorAll(".addon_card")];
  
    const nameInput = document.querySelector('input[name="userName"]');
    const emailInput = document.querySelector('input[name="email"]');
    const phoneInput = document.querySelector('input[name="phone"]');
  
    const billingSwitch = document.getElementById("billing-switch");
    const monthlyLabel = document.getElementById("monthly-label");
    const yearlyLabel = document.getElementById("yearly-label");
  
    let currentStep = 1;
    let isYearly = false;
    let selectedPlan = "";
  
    const plans = {
      Arcade: { monthly: 9, yearly: 90 },
      Advance: { monthly: 12, yearly: 120 },
      Pro: { monthly: 15, yearly: 150 }
    };
  
    const addons = {
      online: {
        name: "Online Services",
        monthly: 1,
        yearly: 10
      },
      storage: {
        name: "Larger Storage",
        monthly: 2,
        yearly: 20
      },
      profile: {
        name: "Customizable Profile",
        monthly: 2,
        yearly: 20
      }
    };
  
    function showStep(stepNumber) {
      currentStep = stepNumber;
  
      steps.forEach((step) => {
        const isActive = Number(step.dataset.content) === stepNumber;
        step.hidden = !isActive;
        step.classList.toggle("active", isActive);
      });
  
      stepItems.forEach((item) => {
        const number = Number(item.dataset.step);
        item.classList.toggle("active", number === stepNumber);
        item.classList.toggle("completed", number < stepNumber);
      });
  
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  
    function showError(input, errorId, message) {
      const errorElement = document.getElementById(errorId);
      errorElement.textContent = message;
      input.classList.toggle("invalid", Boolean(message));
      input.setAttribute("aria-invalid", message ? "true" : "false");
    }
  
    function validatePersonalInfo() {
      let valid = true;
  
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const phone = phoneInput.value.trim();
  
      if (!name) {
        showError(nameInput, "name-error", "Enter your name");
        valid = false;
      } else {
        showError(nameInput, "name-error", "");
      }
  
      if (!email) {
        showError(emailInput, "email-error", "Enter email");
        valid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showError(emailInput, "email-error", "Enter a valid email address");
        valid = false;
      } else {
        showError(emailInput, "email-error", "");
      }
  
      if (!phone) {
        showError(phoneInput, "phone-error", "Enter your mobile number");
        valid = false;
      } else if (!/^[+]?[\d\s()-]{7,20}$/.test(phone)) {
        showError(phoneInput, "phone-error", "Enter a valid mobile number");
        valid = false;
      } else {
        showError(phoneInput, "phone-error", "");
      }
  
      return valid;
    }
  
    function validatePlan() {
      const error = document.getElementById("plan-error");
  
      if (!selectedPlan) {
        error.textContent = "Please select a plan";
        return false;
      }
  
      error.textContent = "";
      return true;
    }
  
    function getPrice(item) {
      return isYearly ? item.yearly : item.monthly;
    }
  
    function getBillingSuffix() {
      return isYearly ? "/yr" : "/mo";
    }
  
    function selectPlan(planName) {
      selectedPlan = planName;
  
      planCards.forEach((card) => {
        const selected = card.dataset.plan === planName;
        card.classList.toggle("selected", selected);
        card.setAttribute("aria-pressed", String(selected));
      });
  
      document.getElementById("plan-error").textContent = "";
      updateSummary();
    }
  
    function updateBilling() {
      billingSwitch.setAttribute("aria-checked", String(isYearly));
  
      monthlyLabel.classList.toggle("selected", !isYearly);
      yearlyLabel.classList.toggle("selected", isYearly);
  
      planCards.forEach((card) => {
        const plan = plans[card.dataset.plan];
        const price = card.querySelector(".plan-price");
        const extra = card.querySelector(".yearly-extra");
  
        price.textContent = `$${getPrice(plan)}${getBillingSuffix()}`;
        extra.hidden = !isYearly;
      });
  
      addonCards.forEach((card) => {
        const input = card.querySelector('input[name="addons"]');
        const addon = addons[input.value];
        const priceElement = card.querySelector(".addon-price");
  
        priceElement.textContent =
          `+$${getPrice(addon)}${getBillingSuffix()}`;
      });
  
      updateSummary();
    }
  
    function updateSummary() {
      if (!selectedPlan) return;
  
      const plan = plans[selectedPlan];
      const suffix = getBillingSuffix();
      let total = getPrice(plan);
  
      document.getElementById("summary-plan-name").textContent =
        `${selectedPlan} (${isYearly ? "Yearly" : "Monthly"})`;
  
      document.getElementById("summary-plan-price").textContent =
        `$${getPrice(plan)}${suffix}`;
  
      const summaryAddons = document.getElementById("summary-addons");
      summaryAddons.replaceChildren();
  
      addonCards.forEach((card) => {
        const input = card.querySelector('input[name="addons"]');
  
        if (!input.checked) return;
  
        const addon = addons[input.value];
        const price = getPrice(addon);
        total += price;
  
        const row = document.createElement("div");
        row.className = "summary-addon";
  
        const name = document.createElement("span");
        name.textContent = addon.name;
  
        const amount = document.createElement("strong");
        amount.textContent = `+$${price}${suffix}`;
  
        row.append(name, amount);
        summaryAddons.appendChild(row);
      });
  
      document.getElementById("total-label").textContent =
        isYearly ? "Total (per year)" : "Total (per month)";
  
      document.getElementById("summary-total").textContent =
        `$${total}${suffix}`;
    }
  
    document.getElementById("next-button").addEventListener("click", () => {
      if (validatePersonalInfo()) {
        showStep(2);
      }
    });
  
    document.querySelectorAll("[data-next]").forEach((button) => {
      button.addEventListener("click", () => {
        if (currentStep === 2 && !validatePlan()) return;
  
        if (currentStep === 3) {
          updateSummary();
        }
  
        showStep(currentStep + 1);
      });
    });
  
    document.querySelectorAll("[data-back]").forEach((button) => {
      button.addEventListener("click", () => {
        showStep(Number(button.dataset.back));
      });
    });
  
    planCards.forEach((card) => {
      card.addEventListener("click", () => {
        selectPlan(card.dataset.plan);
      });
    });
  
    billingSwitch.addEventListener("click", () => {
      isYearly = !isYearly;
      updateBilling();
    });
  
    addonCards.forEach((card) => {
      const input = card.querySelector('input[name="addons"]');
  
      input.addEventListener("change", updateSummary);
  
      card.addEventListener("keydown", (event) => {
        if (
          (event.key === "Enter" || event.key === " ") &&
          event.target === card
        ) {
          event.preventDefault();
          input.checked = !input.checked;
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
      });
    });
  
    document.getElementById("change-plan").addEventListener("click", () => {
      showStep(2);
    });
  
    document.getElementById("confirm-button").addEventListener("click", () => {
      updateSummary();
      showStep(5);
    });
  
    [
      [nameInput, "name-error"],
      [emailInput, "email-error"],
      [phoneInput, "phone-error"]
    ].forEach(([input, errorId]) => {
      input.addEventListener("input", () => {
        if (input.value.trim()) {
          showError(input, errorId, "");
        }
      });
    });
  
    form.addEventListener("submit", (event) => {
      event.preventDefault();
    });
  
    updateBilling();
    showStep(1);
  });
  